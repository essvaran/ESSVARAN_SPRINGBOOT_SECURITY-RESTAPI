package com.week17.Week17Graded;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Week17GradedApplicationTests {

	@Test
	void contextLoads() {
	}

}
